#!/bin/bash 

 cd /kuberadir/share 

 sbatch xyz.sh > id.txt