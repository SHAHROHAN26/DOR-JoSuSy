from django.apps import AppConfig


class JosusyAppConfig(AppConfig):
    name = 'josusy_app'
