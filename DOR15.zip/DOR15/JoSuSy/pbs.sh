#!/bin/bash 

 #PBS -N j0

 #PBS -q longq

 #PBS -l select=1:ncpus=1

 #PBS -l walltime=0:1:00 

 source dfghjk

 mpirun dfghj