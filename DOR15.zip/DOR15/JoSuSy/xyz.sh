#!/bin/bash 

#SBATCH --job-name=j001
#SBATCH --partition=PRADYUT 
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=2
#SBATCH --time=0:20:00
/kuberadir/share/installed-software/mpich-3.1/bin/mpirun /kuberadir/share/a.out