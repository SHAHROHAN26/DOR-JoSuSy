#!/bin/bash 

#SBATCH --job-name=j0
#SBATCH --partition=PRADYUT 
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --time=10:00:00
/kuberadir/share/installed-software/mpich-3.1/bin/mpirun /kuberadir/share/a.out